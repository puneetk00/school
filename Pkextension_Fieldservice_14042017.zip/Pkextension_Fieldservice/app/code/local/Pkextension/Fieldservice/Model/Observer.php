<?php
class Pkextension_Fieldservice_Model_Observer
{
			public function update($observer) {
				//die("here");
				$action = $observer->getEvent()->getAction(); 
				$layout = $observer->getEvent()->getLayout();
				Mage::log($action->getFullActionName() , null, "test.log");
				if ($action->getFullActionName() == 'catalog_product_view') {
					$root = $layout->getBlock('product.info');
					if ($root) {
						Mage::log('Could not find' , null, "test.log");
						$root->setTemplate('customelayout/product/view.phtml');
					}else{
						Mage::log('Could not find product.info block' , null, "test.log");
					}
				}
			}
			
			public function addtocartdate($observer) {
				$item = $observer->getEvent();
				print_r($item);
				die("here");
				$action = $observer->getEvent()->getAction(); 
				$layout = $observer->getEvent()->getLayout();
				Mage::log($action->getFullActionName() , null, "test.log");
				if ($action->getFullActionName() == 'catalog_product_view') {
					$root = $layout->getBlock('product.info');
					if ($root) {
						Mage::log('Could not find' , null, "test.log");
						$root->setTemplate('customelayout/product/view.phtml');
					}else{
						Mage::log('Could not find product.info block' , null, "test.log");
					}
				}
			}
		
}
